#!/usr/bin/env bash
#
# Run jekyll serve and then launch the site
#
# v2.6.1
# https://github.com/cotes2020/jekyll-theme-chirpy
# © 2020 Cotes Chung
# MIT Licensed

bundle exec jekyll s -H 0.0.0.0 -l

